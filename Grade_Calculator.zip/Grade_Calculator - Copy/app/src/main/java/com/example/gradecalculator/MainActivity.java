package com.example.gradecalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText num1;
    private EditText num2;
    private EditText num3;
    private EditText num4;
    private Button cal;
    private Button reset;
    private TextView sum;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num1 = (EditText)findViewById(R.id.etNum1);
        num2 = (EditText)findViewById(R.id.etNum2);
        num3 = (EditText)findViewById(R.id.etNum3);
        num4 = (EditText)findViewById(R.id.etNum4);
        cal = (Button)findViewById(R.id.btn1);
        reset = (Button)findViewById(R.id.btn2);
        sum = (TextView)findViewById(R.id.tvResult);

        cal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int Number1 = Integer.parseInt(num1.getText().toString());
                int Number2 = Integer.parseInt(num2.getText().toString());
                int Number3 = Integer.parseInt(num3.getText().toString());
                int Number4 = Integer.parseInt(num4.getText().toString());
                int Answer = Number1 + Number2 + Number3 + Number4;
                if (Answer >= 89){//If Open
                    sum.setText("Result: A");
                }//If Close
                else if (Answer >= 79 && Answer < 89){//else if open
                    sum.setText("Result: B");
                }//else if close
                else if (Answer >= 69 && Answer < 79){//else if open
                    sum.setText("Result: C");
                }//else if close
                else if (Answer >= 50  && Answer < 69){//else if open
                    sum.setText("Result: D");
                }//else if close
                else if (Answer < 50){//else if open
                    sum.setText("Result: F");
                }//else if close
            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sum.setText("Result: ");
                num1.setText("");
                num2.setText("");
                num3.setText("");
                num4.setText("");
            }
        });








    }
}